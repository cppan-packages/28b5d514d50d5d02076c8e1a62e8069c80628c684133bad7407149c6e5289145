﻿#pragma once    // Source encoding: utf-8 with BOM ∩
// #include <stdlib/algorithm.hpp>
//
// Algorithms that operate on containers.
// Copyright © 2017 Alf P. Steinbach, distributed under Boost license 1.0.

#include <stdlib/fix/msvc_wolfcalls_about_std_functions.hpp>
#include <algorithm>
#include <stdlib/all/non_io_fixes.hpp>
