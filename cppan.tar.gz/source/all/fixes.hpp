﻿#pragma once    // Source encoding: utf-8 with BOM ∩
// #include <stdlib/all/fixes.hpp>
// Copyright © 2017 Alf P. Steinbach, distributed under Boost license 1.0.

#include <stdlib/all/non_io_fixes.hpp>
#include <stdlib/fix/console_io.hpp>
#include <stdlib/fix/output_of_implicit_wide_c_string.hpp>
