﻿#pragma once    // Source encoding: utf-8 with BOM ∩
// #include <stdlib/all/localization.hpp>
// Copyright © 2017 Alf P. Steinbach, distributed under Boost license 1.0.

#include <stdlib/all/text/c_localization.hpp>
#include <stdlib/all/text/cpp_localization.hpp>
