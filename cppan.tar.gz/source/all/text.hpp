﻿#pragma once    // Source encoding: utf-8 with BOM ∩
// #include <stdlib/all/text.hpp>
// Copyright © 2017 Alf P. Steinbach, distributed under Boost license 1.0.

// The text headers listed by (http://en.cppreference.com/w/cpp/header).

#include <stdlib/all/localization.hpp>
#include <stdlib/all/text/c_strings.hpp>
#include <stdlib/all/text/cpp_strings.hpp>
