﻿#pragma once    // Source encoding: utf-8 with BOM ∩
// #include <stdlib/ios.hpp>
//
// std::ios_base class, std::basic_ios class template and several typedefs.
// Copyright © 2017 Alf P. Steinbach, distributed under Boost license 1.0.

#include <stdlib/fix/msvc_wolfcalls_about_std_functions.hpp>
#include <stdlib/ioswfd.hpp>
#include <ios>
#include <stdlib/all/non_io_fixes.hpp>
