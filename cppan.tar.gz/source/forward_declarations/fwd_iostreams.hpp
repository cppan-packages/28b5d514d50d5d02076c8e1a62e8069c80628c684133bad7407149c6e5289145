﻿#pragma once    // Source encoding: utf-8 with BOM ∩
// #include <stdlib/forward_declarations/fwd_iostreams.hpp>
//
// Forward declarations of all classes in the input/output part of the library.
// Copyright © 2017 Alf P. Steinbach, distributed under Boost license 1.0.

#include <stdlib/ioswfd.hpp>
