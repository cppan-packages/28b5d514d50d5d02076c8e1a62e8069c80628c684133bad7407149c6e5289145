﻿#pragma once    // Source encoding: utf-8 with BOM ∩
// #include <stdlib/extension/impl/linux_process_command_line.hpp>
//
// Copyright © 2017 Your Name, distributed under Boost license 1.0.

#ifndef STDLIB_USE_CUSTOM_COMMAND_LINE_IMPL
#   error This file is only meaningful with STDLIB_USE_CUSTOM_COMMAND_LINE_IMPL.
#endif

#include <stdlib/extension/process_command_line.declarations.hpp>

// ...
#error Not implemented (replace this file with your implementation)
